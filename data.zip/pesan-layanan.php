<?php
session_start();
require 'koneksi.php';

// Validasi otentikasi sesi dan hak akses pengguna
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'pelanggan') {
    header("Location: signin.php");
    exit();
}

// Pemrosesan formulir permintaan layanan (POST request)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_SESSION['email']; 
    $nama_pemilik = $_POST['nama_pemilik'];
    $merek_sepatu = $_POST['merek_sepatu'];
    $paket = $_POST['paket_treatment'];
    $logistik = $_POST['opsi_logistik'];
    
    $alamat_murni = $_POST['alamat_penjemputan'];
    $link_maps = isset($_POST['link_maps']) ? $_POST['link_maps'] : '';

    // Integrasi string alamat penjemputan manual dengan URL koordinat Geolocation
    if ($logistik === 'Kurir Pick-up' && !empty($link_maps)) {
        $alamat = $alamat_murni . " [MAPS_URL] " . $link_maps;
    } else {
        $alamat = $alamat_murni;
    }

    // Persiapan query aman dengan Prepared Statements untuk mencegah SQL Injection
    $stmt = $koneksi->prepare("INSERT INTO tabel_pesanan (email_pelanggan, nama_pemilik, merek_sepatu, paket_treatment, opsi_logistik, alamat_penjemputan, status_pesanan) VALUES (?, ?, ?, ?, ?, ?, 'Belum Bayar')");
    
    if($stmt->execute([$email, $nama_pemilik, $merek_sepatu, $paket, $logistik, $alamat])) {
        $id_order_baru = $koneksi->lastInsertId(); 
        
        echo "<script>
                alert('Pesanan berhasil dibuat! Silakan lakukan pembayaran di halaman Riwayat Pesanan Anda.');
                window.location.href = 'riwayat-pesanan.php'; 
              </script>";
    } else {
        echo "<script>alert('Gagal mengirimkan pesanan layanan. Silakan coba kembali.');</script>";
    }
}
?>
<!doctype html>
<html lang="id" class="scroll-smooth">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pesan Layanan | The Clean</title>
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
    <link class="main-css" rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="./src/css/tailwind.css" />

    <script src="assets/js/wow.min.js"></script>
    <script>
      new WOW().init();
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>tailwind.config = { darkMode: "class" }</script>
  </head>

  <body class="bg-white text-gray-800 dark:bg-slate-900 dark:text-gray-100">
    <header class="absolute top-0 left-0 z-40 flex items-center w-full bg-transparent ud-header">
      <div class="container px-4 mx-auto">
        <div class="relative flex items-center justify-between -mx-4">
          <div class="max-w-full px-4 w-60">
            <a href="index.php" class="py-5 text-2xl font-bold text-white navbar-logo flex items-center gap-2">
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa-htm3zT2h1cQ2cDBt_1K-2Lt_lviW4Y7oQ&s" alt="Logo The Clean" class="w-8 h-8 rounded-md object-contain" />
              <span>The Clean.</span>
            </a>
          </div>
          <div class="flex items-center justify-between w-full px-4">
            <div>
              <button id="navbarToggler" class="absolute right-4 top-1/2 block -translate-y-1/2 rounded-lg px-3 py-[6px] ring-primary focus:ring-2 lg:hidden">
                <span class="relative my-[6px] block h-[2px] w-[30px] bg-white ud-menu-toggle"></span>
                <span class="relative my-[6px] block h-[2px] w-[30px] bg-white ud-menu-toggle"></span>
                <span class="relative my-[6px] block h-[2px] w-[30px] bg-white ud-menu-toggle"></span>
              </button>
              <nav id="navbarCollapse" class="absolute right-4 top-full hidden w-full max-w-[250px] rounded-lg bg-white py-5 shadow-lg lg:static lg:block lg:w-full lg:max-w-full lg:bg-transparent lg:shadow-none xl:px-6 dark:bg-slate-800 lg:dark:bg-transparent">
                <ul class="block lg:flex lg:items-center 2xl:ml-20">
                  <li class="relative group">
                    <a href="pesan-layanan.php" class="flex py-2 mx-8 text-base font-medium text-blue-600 lg:text-blue-400 dark:text-blue-400 lg:py-6 transition-colors duration-200 whitespace-nowrap">Pesan Layanan</a>
                  </li>
                  <li class="relative group">
                    <a href="riwayat-pesanan.php" class="flex py-2 mx-8 text-base font-medium text-dark dark:text-white lg:text-white lg:py-6 hover:text-blue-600 lg:hover:text-blue-400 dark:hover:text-blue-400 transition-colors duration-200 whitespace-nowrap">Riwayat Pesanan</a>
                  </li>
                </ul>
              </nav>
            </div>
            <div class="hidden sm:flex items-center justify-end pr-16 lg:pr-0 gap-4">
              <span class="text-white text-base font-medium hidden lg:inline" id="userGreeting">Halo, <?php echo htmlspecialchars($_SESSION['nama_user'] ?? 'Pelanggan'); ?></span>
              <a href="logout.php" class="px-6 py-2 text-base font-medium text-white duration-300 ease-in-out rounded-md bg-white/20 hover:bg-white/100 hover:text-red-600 theme-logout">Keluar</a>
              
              <button id="themeToggler" class="flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors" aria-label="theme toggler">
                <svg id="sunIcon" class="w-5 h-5 hidden" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 11-2 0V3a1 1 0 011-1zm4.243 3.05a1 1 0 010 1.414l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zm-3.05 4.243a1 1 0 011.414 0l.707.707a1 1 0 01-1.414 1.414l-.707-.707a1 1 0 010-1.414zM10 14a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zm-4.243-3.05a1 1 0 010 1.414l.707-.707a1 1 0 111.414 1.414l-.707.707a1 1 0 01-1.414 0zM3 10a1 1 0 011-1h1a1 1 0 110 2H4a1 1 0 01-1-1zm3.05-4.243a1 1 0 010 1.414l-.707.707a1 1 0 111.414 1.414l-.707.707a1 1 0 01-1.414 0zM10 5a5 5 0 100 10 5 5 0 000-10z" clip-rule="evenodd"></path>
                </svg>
                <svg id="moonIcon" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"></path>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>

    <section class="relative overflow-hidden bg-blue-600 pt-[120px] pb-[60px] md:pt-[130px] lg:pt-[160px] z-10">
      <div class="absolute left-0 top-0 -z-10 h-80 w-80 rounded-full bg-gradient-to-br from-teal-400/20 to-indigo-500/30 blur-3xl pointer-events-none"></div>
      <div class="absolute right-0 bottom-0 -z-10 h-[350px] w-[350px] rounded-full bg-gradient-to-tr from-cyan-400/20 to-emerald-400/20 blur-3xl pointer-events-none"></div>
      
      <div class="container px-4 mx-auto">
        <div class="hero-content mx-auto max-w-[780px] text-center wow fadeInUp" data-wow-delay=".2s">
          <h1 class="mb-2 text-3xl font-bold leading-snug text-white sm:text-4xl lg:text-5xl">Dashboard Layanan Mandiri</h1>
          <p class="mx-auto text-base font-medium text-blue-100 sm:text-lg max-w-[600px]">Kelola transaksi pengerjaan cuci sepatu Anda mulai dari pemesanan, pemantauan status antrean, hingga upload konfirmasi pembayaran.</p>
        </div>
      </div>
    </section>

    <section id="pesan" class="pt-16 pb-20 dark:bg-slate-900">
      <div class="container px-4 mx-auto">
        <div class="max-w-[800px] mx-auto bg-white dark:bg-slate-800 rounded-xl p-8 shadow-md border dark:border-slate-700 wow fadeInUp" data-wow-delay=".1s">
          <div class="mb-6 flex items-center gap-3 border-b dark:border-slate-700 pb-4">
            <div class="flex items-center justify-center w-[50px] h-[50px] bg-blue-600 rounded-xl p-3 shadow-lg shadow-blue-500/50 dark:shadow-blue-500/30">
              <img src="https://cdn-icons-png.flaticon.com/128/3829/3829385.png" alt="Icon Pemesanan" class="w-full h-full object-contain brightness-0 invert" />
            </div>
            <h2 class="text-2xl font-bold text-dark dark:text-white">Form Pemesanan Layanan</h2>
          </div>
          
          <form method="POST" action="" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-semibold mb-2">Nama Pemilik Sepatu</label>
                <input type="text" name="nama_pemilik" placeholder="Masukkan nama" class="w-full px-4 py-3 rounded-md bg-white dark:bg-slate-700 border dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm" required />
              </div>
              <div>
                <label class="block text-sm font-semibold mb-2">Merek / Jenis Sepatu</label>
                <input type="text" name="merek_sepatu" placeholder="Contoh: Sneaker Nike AirMax (Hitam)" class="w-full px-4 py-3 rounded-md bg-white dark:bg-slate-700 border dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm" required />
              </div>
            </div>
            
            <div>
              <label class="block text-sm font-semibold mb-2">Pilihan Paket Treatment</label>
              <select name="paket_treatment" class="w-full px-4 py-3 rounded-md bg-white dark:bg-slate-700 border dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm" required>
                <option value="Fast Clean">Fast Clean - Rp 20.000 (Pencucian Cepat Bagian Luar)</option>
                <option value="Deep Clean">Deep Clean - Rp 25.000 (Pencucian Menyeluruh Noda Berat)</option>
                <option value="Express Clean">Express Clean - Rp 45.000 (Prioritas Cepat + Free Delivery Kurir)</option>
              </select>
            </div>

            <div>
              <label class="block text-sm font-semibold mb-2">Opsi Logistik Penjemputan</label>
              <select name="opsi_logistik" id="logistik" onchange="aturLogistik()" class="w-full px-4 py-3 rounded-md bg-white dark:bg-slate-700 border dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm" required>
                <option value="" disabled selected>-- Pilih Metode Penyerahan Sepatu --</option>
                <option value="Antar Sendiri">Datang & Antar Sendiri Langsung ke Toko Gerai</option>
                <option value="Kurir Pick-up">Gunakan Layanan Antar-Jemput (Pick-Up Service)</option>
              </select>
            </div>

            <div id="kotakAlamat" class="hidden transition-all duration-300 space-y-4 p-4 border border-blue-100 dark:border-slate-600 bg-blue-50/30 dark:bg-slate-700/30 rounded-xl">
              
              <div>
                <label class="block text-sm font-semibold mb-2 text-emerald-600 dark:text-emerald-400 flex items-center gap-1">Langkah 1: Sinkronisasi Lokasi Perangkat (Rekomendasi)</label>
                <button type="button" id="btnGPS" class="w-full flex items-center justify-center gap-2 px-4 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-sm rounded-md shadow-md transition-all duration-200">
                  📍 Deteksi Koordinat Otomatis Lewat GPS Perangkat
                </button>
              </div>

              <input type="hidden" name="link_maps" id="inputMaps" />

              <div>
                <label class="block text-sm font-semibold mb-1">Langkah 2: Tulis Detail Rumah / Patokan <span class="text-red-500">*</span></label>
                <textarea name="alamat_penjemputan" id="inputAlamat" rows="3" placeholder="Contoh: Jl. Veteran No.14, Perumahan Asri Blok C, Rumah cat kuning pagar hijau (Samping warung bakso)" class="w-full px-4 py-3 rounded-md bg-white dark:bg-slate-700 border dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm"></textarea>
                <p class="text-xs text-amber-600 dark:text-amber-400 mt-1 font-medium">*Silakan lengkapi nama jalan, nomor rumah, atau patokan terdekat untuk mempermudah identifikasi rute logistik oleh kurir.</p>
              </div>
            </div>

            <div id="kotakMaps" class="hidden transition-all duration-300">
              <label class="block text-sm font-semibold mb-2 text-blue-600 dark:text-blue-400">📍 Lokasi Toko The Clean (Drop-off Sepatu)</label>
              <div class="rounded-lg overflow-hidden border-2 border-blue-200 dark:border-blue-800 shadow-sm">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3953.5134707248174!2d110.83864417500588!3d-7.683515892332152!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a3c71a0433cb3%3A0xe84403c0c99c758b!2sAlfamidi!5e0!3m2!1sid!2sid!4v1718868840212!5m2!1sid!2sid" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
              </div>
              <p class="text-xs text-gray-500 dark:text-gray-400 mt-2 italic">*Titik Drop-off: Alfamidi Veteran. Tunjukkan bukti pesanan (invoice) ke kasir saat Anda tiba.</p>
            </div>
            
            <button type="submit" class="w-full py-3 mt-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-md shadow-md transition duration-300 text-sm">Kirim Order & Cetak Ringkasan Pesanan</button>
          </form>
        </div>
      </div>
    </section>

    <footer class="relative z-10 bg-[#090E34] pt-8 text-gray-300 overflow-hidden">
      <div class="border-t border-white border-opacity-10 py-8 bg-[#0b113c]">
        <div class="container px-4 mx-auto text-center">
          <p class="text-base text-[#959CB1]">
            &copy; 2026 The Clean Cleaning Shoes and Care - Kelompok 2. All rights reserved.
          </p>
        </div>
      </div>
    </footer>

    <script>
      function aturLogistik() {
        var pilihan = document.getElementById("logistik").value;
        var kotakAlamat = document.getElementById("kotakAlamat");
        var inputAlamat = document.getElementById("inputAlamat");
        var inputMaps = document.getElementById("inputMaps");
        var kotakMaps = document.getElementById("kotakMaps");

        if (pilihan === "Kurir Pick-up") {
            kotakAlamat.classList.remove("hidden");
            inputAlamat.setAttribute("required", "true");
            inputAlamat.removeAttribute("minlength"); 
            inputAlamat.value = ""; 
            inputMaps.value = "";
            kotakMaps.classList.add("hidden");
        } 
        else if (pilihan === "Antar Sendiri") {
            kotakAlamat.classList.add("hidden");
            inputAlamat.removeAttribute("required");
            inputAlamat.value = "Diantar langsung oleh pelanggan ke toko The Clean";
            inputMaps.value = "";
            kotakMaps.classList.remove("hidden");
        }
      }
    </script>

    <script>
      const btnGPS = document.getElementById('btnGPS');
      const inputAlamat = document.getElementById('inputAlamat');
      const inputMaps = document.getElementById('inputMaps');

      btnGPS.addEventListener('click', function() {
        if (!navigator.geolocation) {
          alert("Fitur Geolocation tidak didukung oleh browser Anda. Harap isi alamat secara manual pada kolom yang tersedia.");
          return;
        }

        // Efek transisi proses sinkronisasi koordinat GPS perangkat
        btnGPS.innerText = "⏳ Sedang Memproses Sinkronisasi Koordinat Lokasi...";
        btnGPS.className = "w-full flex items-center justify-center gap-2 px-4 py-3 bg-amber-500 text-white font-bold text-sm rounded-md shadow-md animate-pulse pointer-events-none";

        navigator.geolocation.getCurrentPosition(
          function(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            // Menyimpan URL koordinat peta ke element input hidden
            inputMaps.value = `https://www.google.com/maps?q=${lat},${lng}`;

            // Mengubah status indikator tombol menjadi berhasil
            btnGPS.innerText = "✅ Koordinat Lokasi Berhasil Disinkronisasi!";
            btnGPS.className = "w-full flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white font-bold text-sm rounded-md shadow-md pointer-events-none";
            
            // Memindahkan fokus input ke kolom detail alamat
            inputAlamat.placeholder = "Koordinat berhasil dikunci. Sila lengkapi dengan patokan spesifik fisik bangunan di sini.";
            inputAlamat.focus();
            
            alert("Sinkronisasi Berhasil! Koordinat lokasi presisi telah terintegrasi. Harap lengkapi deskripsi patokan bangunan fisik pada formulir Langkah 2.");
          },
          function(error) {
            btnGPS.innerText = "❌ Gagal Mengakses Geolocation";
            btnGPS.className = "w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-600 text-white font-bold text-sm rounded-md shadow-md";
            alert("Gagal mendeteksi lokasi secara otomatis. Pastikan setelan izin akses lokasi (GPS) pada peramban web/browser Anda berada pada status 'Allow/Izinkan'.");
          },
          { enableHighAccuracy: true, timeout: 8000 }
        );
      });
    </script>

    <script>
      window.onscroll = function () {
        const ud_header = document.querySelector(".ud-header");
        const logo = document.querySelector(".navbar-logo");
        const navLinks = ud_header.querySelectorAll("nav ul li a");
        const userGreeting = document.getElementById("userGreeting");
        const logoutBtn = ud_header.querySelector(".theme-logout");
        const themeToggler = document.getElementById('themeToggler');
        const menuToggle = ud_header.querySelectorAll(".ud-menu-toggle");

        if (window.pageYOffset > 50) {
          ud_header.classList.remove("absolute", "bg-transparent");
          ud_header.classList.add("fixed", "bg-white", "dark:bg-slate-900", "shadow-md", "z-50", "transition-all", "duration-200");
          logo.classList.remove("text-white");
          logo.classList.add("text-blue-600", "dark:text-white");
          themeToggler.classList.remove("text-white");
          themeToggler.classList.add("text-gray-800", "dark:text-white");

          if (userGreeting) {
            userGreeting.classList.remove("text-white");
            userGreeting.classList.add("text-gray-800", "dark:text-gray-200");
          }
          menuToggle.forEach(toggle => {
            toggle.classList.remove("bg-white");
            toggle.classList.add("bg-dark", "dark:bg-white");
          });
          navLinks.forEach(link => {
            if(link.getAttribute('href') === 'pesan-layanan.php') {
              link.classList.remove("lg:text-white");
              link.classList.add("text-blue-600", "dark:text-blue-400");
            } else {
              link.classList.remove("lg:text-white");
              link.classList.add("text-gray-800", "dark:text-gray-200");
            }
          });
          if (logoutBtn) {
            logoutBtn.classList.remove("text-white", "bg-white/20", "hover:bg-white/100", "hover:text-red-600");
            logoutBtn.classList.add("bg-red-600", "text-white", "hover:bg-red-700");
          }
        } else {
          ud_header.classList.remove("fixed", "bg-white", "dark:bg-slate-900", "shadow-md", "z-50");
          ud_header.classList.add("absolute", "bg-transparent");
          logo.classList.remove("text-blue-600", "dark:text-white");
          logo.classList.add("text-white");
          themeToggler.classList.remove("text-gray-800", "dark:text-white");
          themeToggler.classList.add("text-white");

          if (userGreeting) {
            userGreeting.classList.remove("text-gray-800", "dark:text-gray-200");
            userGreeting.classList.add("text-white");
          }
          menuToggle.forEach(toggle => {
            toggle.classList.remove("bg-dark", "dark:bg-white");
            toggle.classList.add("bg-white");
          });
          navLinks.forEach(link => {
            if(link.getAttribute('href') === 'pesan-layanan.php') {
              link.classList.add("lg:text-blue-400");
            } else {
              link.classList.remove("text-gray-800", "dark:text-gray-200");
              link.classList.add("lg:text-white");
            }
          });
          if (logoutBtn) {
            logoutBtn.classList.remove("bg-red-600", "hover:bg-red-700");
            logoutBtn.classList.add("text-white", "bg-white/20", "hover:bg-white/100", "hover:text-red-600");
          }
        }
      };

      const navbarToggler = document.querySelector("#navbarToggler");
      const navbarCollapse = document.querySelector("#navbarCollapse");

      navbarToggler.addEventListener("click", () => {
        navbarToggler.classList.toggle("navbarTogglerActive");
        navbarCollapse.classList.toggle("hidden");
      });

      document.querySelectorAll("#navbarCollapse ul li a").forEach((e) =>
        e.addEventListener("click", () => {
          navbarToggler.classList.remove("navbarTogglerActive");
          navbarCollapse.classList.add("hidden");
        })
      );

      const themeToggler = document.getElementById('themeToggler');
      const sunIcon = document.getElementById('sunIcon');
      const moonIcon = document.getElementById('moonIcon');

      if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
        sunIcon.classList.remove('hidden');
        moonIcon.classList.add('hidden');
      } else {
        document.documentElement.classList.remove('dark');
        sunIcon.classList.add('hidden');
        moonIcon.classList.remove('hidden');
      }

      themeToggler.addEventListener('click', () => {
        if (document.documentElement.classList.contains('dark')) {
          document.documentElement.classList.remove('dark');
          localStorage.setItem('theme', 'light');
          sunIcon.classList.add('hidden');
          moonIcon.classList.remove('hidden');
        } else {
          document.documentElement.classList.add('dark');
          localStorage.setItem('theme', 'dark');
          sunIcon.classList.remove('hidden');
          moonIcon.classList.add('hidden');
        }
      });
    </script>
  </body>
</html>